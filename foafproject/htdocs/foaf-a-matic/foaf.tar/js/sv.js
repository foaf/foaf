
var field_friend='V�n';
var field_title='Titel (Herr, Fru, Doktor, etc)';
var field_firstName='F�rnamn';
var field_surname='Efternamn';
var field_nick='Smeknamn';
var field_email='Din e-postadress';
var field_homepage='Hemsida';
var field_depiction='Din bild';
var field_phone='Telefonnummer';
var field_workplaceHomepage='Arbetets hemsida';
var field_workInfoHomepage='Sida som beskriver vad du arbetar med';
var field_schoolHomepage='Skolans hemsida';
var field_spamProtect='Skydda e-postadresser fr�n spam';
var field_friendEmail='E-postadress';
var field_friendName='Namn';
var field_friendSeeAlso='Se ocks�';
var msg_missingRequired='Du m�ste fylla i dessa f�lt:';
var msg_missingFriendEmail='En e-postadress till ?';