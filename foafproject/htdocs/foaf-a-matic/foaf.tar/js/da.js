
var field_title='Titel (Hr, Fr, Frk osv.)';
var field_firstName='Fornavn';
var field_surname='Efternavn';
var field_nick='K�lenavn';
var field_email='E-mail-adresse';
var field_homepage='Hjemmeside';
var field_depiction='URL for fotografi';
var field_phone='Telefonnummer';
var field_workplaceHomepage='URL for dit arbejdes hjemmeside';
var field_workInfoHomepage='URL med beskrivelse af hvad du laver p� arbejdet';
var field_schoolHomepage='URL for skolens hjemmeside';
var field_spamProtect='Beskyt e-mail-adresser fra spammere';
var field_friend='Ven';
var field_friendEmail='E-mail';
var field_friendName='Navn';
var field_friendSeeAlso='Se ogs�';
var msg_missingRequired='Du mangler at udfylde f�lgende felter:';
var msg_missingFriendEmail='En e-mail-adresse for ?';