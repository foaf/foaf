#!/bin/sh
java -jar foaf-a-matic.jar
