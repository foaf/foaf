THE FOAF-A-MATIC MARK 2
===============================================================

The FOAF-a-Matic Mark 2 is a Java tool for creating, editing 
and managing FOAF ("Friend of a Friend") descriptions.

For information on the vocabulary see [1,2]. For a general 
introduction read Edd Dumbill's excellent introductory article [3].

For more information about the FOAF-a-Matic (both Mark 1 and Mark 2) 
and other FOAF related hackery of mine see [4].

PROJECT STRUCTURE
===============================================================

.classpath     This and the following file are an Eclipse 2.0 [5]
.project       project.

BUILD.txt      Instructions for building the application
CREDITS.txt    Thanks to various people for help and encouragement
LICENSE.txt    FOAF-a-Matic license
README.txt     This file

run.bat        Win32 batch file to execute the application
run.sh         Shell script to execute the application
\bin           Build directory
\doc           Project documentation
\doc\api       API documentation (javadoc)
\lib           Required libraries for running the project and tests
\src        
\src\java      Java source
\src\resources Icons, UI descriptions, etc
\src\tests     Test case source

MORE INFORMATION?
===============================================================

If you're thirsty for more then drop me a line: leigh@ldodds.com

REFERENCES
===============================================================

[1]. http://rdfweb.org/2000/08/why/
[2]. http://xmlns.com/foaf/0.1/
[3]. http://www-106.ibm.com/developerworks/xml/library/x-foaf.html
[4]. http://www.ldodds.com/foaf/
[5]. http://www.eclipse.org

L. Dodds
December 2002
leigh@ldodds.com