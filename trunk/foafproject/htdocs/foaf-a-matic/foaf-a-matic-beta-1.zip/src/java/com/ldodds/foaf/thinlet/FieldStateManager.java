package com.ldodds.foaf.thinlet;

import java.util.Map;
import java.util.HashMap;

import com.ldodds.foaf.thinlet.*;

/**
 * 
 * @author ldodds
 */
public class FieldStateManager
{

	private Map _fieldStates;
	
	public FieldStateManager()
	{
		_fieldStates = new HashMap();		
	}

    public void addFieldState(Object field, FieldState state)
    {
        _fieldStates.put(field, state);
    }

	public void checkState(String name)
	{    
        Object label = Services.getComponentManager().find(name + "_label");
        FieldState state = (FieldState)_fieldStates.get(label);
        if (state != null)
        {
            state.reset();
        }
        _fieldStates.remove(label);    
	}
}
