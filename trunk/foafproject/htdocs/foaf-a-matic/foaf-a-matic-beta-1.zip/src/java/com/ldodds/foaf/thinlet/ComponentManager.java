package com.ldodds.foaf.thinlet;

import java.io.*;
import java.awt.Image;
import java.awt.Frame;
import java.lang.reflect.Method;

import com.ldodds.foaf.thinlet.model.Model;


/**
 * An abstraction over the Thinlet API
 * 
 * <p>
 * This class provides an abstraction over the main Thinlet API, plus some 
 * additional helper methods. Adding this interface allows the various helper 
 * classes to be further isolated from the details of the GUI implementation.
 * </p>
 * 
 * @author ldodds
 */
public interface ComponentManager
{
	public Object parse(String path) throws IOException;
	public Object parse(String path, Object handler) throws IOException;
	public Object parse(InputStream in) throws IOException;
	public Object parse(InputStream in,Object handler) throws IOException;	
	public Object find(String name);
	public Object find(Object object, String name);	
	public void setString(Object component, String key, String value);
	public void setChoice(Object component, String key, String value);
	public void setBoolean(Object component, String key, boolean value);
	public void setInteger(Object component, String key, int value);
	public void setIcon(Object component, String key, Image icon);
	public String getString(Object component, String key);
	public String getChoice(Object component, String key);
	public boolean getBoolean(Object component, String key);
	public int getInteger(Object component, String key);
	public Image getIcon(Object component, String key);
	public Image getIcon(String path);
	public Image getIcon(String path, boolean preload);
	public Object getDesktop();
	public Object create(String classname);
	public void add(Object component);
	public void add(Object parent, Object component);
	public void add(Object parent, Object component, int index);
	public void remove(Object component);
	public void removeAll(Object component);
	public void removeAll(Object component, String key);
	public int getCount(Object component);
	public int getCount(Object component, String key);
	public int getSelectedIndex(Object component);
	public Object getItem(Object component, int index);
	public Object getItem(Object component, String key, int index);
	public Object[] getItems(Object component);
}
