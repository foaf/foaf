package com.ldodds.foaf.thinlet;

import java.awt.*;
import java.awt.datatransfer.*;
import java.util.*;
import java.io.*;

import thinlet.*;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.save.*;
import com.ldodds.foaf.thinlet.*;

public class FOAFThinlet extends Thinlet implements ComponentManager
{

	public FOAFThinlet()
	{
		try
		{
			add( parse("/ui/foaf-a-matic.xml") );
            addInstructions();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		getIcon("/icons/foafButton1.gif", true);
	}

	/**
	 * Invoked when the user exits the application
	 */
	public void exit()
	{
		System.exit(0);
	}

	/**
	 * Invoked when the user switches tabs. The method must determine
	 * which tab is now the focus.
	 */
	public void tabchanged()
	{
	}

	/**
	 * Invoked when the user asks the application to save data to the screen.
	 */
	public void saveToScreen()
	{		
		Services.getModelBuilder().build();
		new ScreenGenerator().generate();
	}
		
	/**
	 * Save the data to a file
	 */
	public void saveToFile()
	{
		Services.getModelBuilder().build();
		new FileGenerator().generate();
	}
	
	public void saveToClipboard()
	{
		Services.getModelBuilder().build();
		new ClipboardGenerator().generate();		
	}
	
    /**
     * Shows a dialog
     */
    public void showDialog(String name)
    {
    	Services.getDialogs().showDialog(name);
    }
    
    /**
     * Closes a dialog
     */
    public void closeDialog(Object field, String name)
    {    	
		Services.getDialogs().closeDialog(name);
    }
        
    public void checkState(Object field, String text, String name)
    {
		Services.getFieldStateManager().checkState(name);
    }
    
	public void addFriend()
	{
		new FriendBuilder().addFriendToTable(false);	
	}

    public void updateFriend()
    {
        new FriendBuilder().addFriendToTable(true);
        this.repaint();
    }
    
	public void deleteFriend()
	{
		new FriendBuilder().removeFriendFromTable();
	}

    public void showFriend()
    {
        new FriendBuilder().showSelected();
    }
    		    
    public void addInstructions()
    {
        Object field = find("instructions");

        StringBuffer sb = new StringBuffer();
        try
        {
            InputStream in = this.getClass().getResourceAsStream("/ui/instructions.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line = reader.readLine();
            while (line != null)
            {
                sb.append(line);
                sb.append("\n");
                line = reader.readLine();
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        setString(field, "text", sb.toString());
    }
            
	public static void main(String[] args)
	{
        Thinlet thinlet = new FOAFThinlet();
		new FrameLauncher("FOAF-a-Matic", thinlet, 500, 400);
        Services.init((ComponentManager)thinlet, (Frame)thinlet.getParent());        
	}

}