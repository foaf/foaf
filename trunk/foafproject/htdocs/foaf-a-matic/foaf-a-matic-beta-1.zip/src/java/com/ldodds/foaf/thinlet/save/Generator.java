package com.ldodds.foaf.thinlet.save;

import java.io.*;
import java.util.List;
import java.util.Iterator;
import java.awt.*;
import java.awt.datatransfer.*;

import thinlet.Thinlet;

import com.ldodds.foaf.thinlet.*;
import com.ldodds.foaf.thinlet.model.*;

/**
 * 
 * @author ldodds
 */
public abstract class Generator
{
    protected ComponentManager _thinlet;
    
	public Generator()
	{
		_thinlet = Services.getComponentManager();
	}
	
	public void generate()
	{
        if (Services.getModel().validate())                       
        {
            doGeneration();
            return;
        }        
        showCues();
        Services.getDialogs().showDialog("error-dialog");		
	}

    /**
     * Updates the user interface to add visual cues for the user so they can 
     * work out where the problem data lives. Basically changes the tooltips 
     * to a help message, and the associated icon to an exclamation mark.
     */
    private void showCues()
    {            
            List errors = Services.getModel().getErrors();
            for (Iterator i=errors.iterator(); i.hasNext();)
            {
                ValidationError error = (ValidationError)i.next();
                Object field = _thinlet.find("foaf:" + error.getField() + "_label");
                FieldState state = new FieldState(_thinlet, field);
                state.add("icon", _thinlet.getIcon(field, "icon"));
                state.add("tooltip", _thinlet.getString(field, "tooltip"));                
                Services.getFieldStateManager().addFieldState(field, state);
                _thinlet.setIcon(field, "icon", _thinlet.getIcon("/icons/redface.gif"));
                _thinlet.setString(field, "tooltip", error.getMessage());
            }        
    }
    
	protected abstract void doGeneration();
			
	protected String getFOAFString()
	{
		ByteArrayOutputStream writer = new ByteArrayOutputStream();
		Exporter exporter =Services.getPreferences().getExporter();
		exporter.setOut(writer);		
		return (doExport(exporter) == true ? writer.toString() : null);
	}		
		
	protected boolean doExport(Exporter exporter)
	{
		try
		{
			exporter.start();
			exporter.export(Services.getModel().getCurrentPerson());
			exporter.end();			
			return true;
		} catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}	


    
}
