package com.ldodds.foaf.thinlet;

import com.ldodds.foaf.thinlet.save.*;

/**
 * 
 * @author ldodds
 */
public class Preferences
{

	public Exporter getExporter()
	{
		Object menu = Services.getComponentManager().find("n3");
		if (menu == null || !Services.getComponentManager().getBoolean(menu, "selected"))
		{
			return new RDFExporter();
		}
		return new NotationThreeExporter();
	}
	
	public boolean hideEmailAddresses()
	{
		Object menu = Services.getComponentManager().find("spamProtect");
		if (menu == null || Services.getComponentManager().getBoolean(menu, "selected"))
		{
			return true;
		}
		return false;
	}
}

