package com.ldodds.foaf.thinlet.save;

import java.io.IOException;

/**
 * An object that can be exported into the file system. The exact representation
 * of the object is determined by an <code>Exporter</code>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public interface Exportable
{
    /**
     * Indicates the object should export itself using the given <code>Exporter<code>.
     * 
     * @param exporter the exporter to use
     */
    public void export(Exporter exporter) throws IOException;
}
