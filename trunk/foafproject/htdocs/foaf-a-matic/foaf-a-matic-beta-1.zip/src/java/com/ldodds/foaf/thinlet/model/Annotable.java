package com.ldodds.foaf.thinlet.model;

import java.util.Map;
import java.util.Iterator;
import java.util.List;

/**
 * <p>
 * Describes an object that can be annotated with
 * arbitrary name-value pairs
 * </p>
 *
 * <p>
 * This code is Public Domain.
 * </p>
 *
 * @author Leigh Dodds
 * @version $Id$
 */
public interface Annotable
{
	/**
	 * Adds a property to this object. Existing entries are overwritten.
	 *
	 * @param property the property name
	 * @param value the value of that property
	 */
	public void add(String property, Object value);
    /**
     * Adds a list property to this object.
     */
    public void addAsList(String property, Object value);
	/**
	 * Copies properties from one <code>Annotable</code> object into
	 * another. Existing properties in this object will be overwritten from
	 * those defined in the other.
	 *
	 * @param other the object to copy properties from
	 */
	public void add(Annotable other);
	/**
	 * Gets a named property.
	 *
	 * @param property the name of the property
	 * @return the value of the property, or <code>null</code> if it is not set
	 */
	public Object get(String property);
	/**
	 * Gets a named property as a List.
	 * 
	 * @param property the name of the property
	 * @return the list of values for this property. The list may be empty.
	 */
	public List getAsList(String property);
	/**
	 * Tests whether this <code>Annotable</code> has a given property
	 *
	 * @param property the property to check
	 * @return <code>true</code> if the property has a value, <code>false</code> otherwise
	 */
	public boolean has(String property);
    /**
     * Get the list of properties defined in this object
     * 
     * @return an unmodifiable Map of the properties
     */
    public Map getProperties();
}