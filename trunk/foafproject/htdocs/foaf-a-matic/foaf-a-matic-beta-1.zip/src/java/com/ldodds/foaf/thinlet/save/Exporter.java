package com.ldodds.foaf.thinlet.save;

import java.io.OutputStream;
import java.io.IOException;

import com.ldodds.foaf.thinlet.model.*;

/**
 * <p>
 * An object capable of exporting FOAF objects into a 
 * provided <code>Outputstream</code>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public interface Exporter
{
    /**
     * <p>
     * Set the stream into which objects should be exported.
     * </p>
     * <p>
     * Provides the exporter with an <code>OutputStream</code> into 
     * which it should store the <code>Exportable<code> objects its 
     * asked to save.
     * </p>
     * <p>
     * An OutputStream is used rather than a Writer because the output format 
     * may be binary. However the Exporter is free to wrap this stream in a Writer 
     * for character based output, and equally may decide to add buffering for 
     * efficiency.
     * </p>
     * @param out the outputstream
     */
    public void setOut(OutputStream out);
    
    /**
     * Exports a person
     */
    public void export(Person p) throws IOException;

    /**
     * Exports a document
     */
    public void export(Document d) throws IOException;    
    
    /**
     * Exports a resource
     */
    public void export(Resource r) throws IOException;
    
    /**
     * Exports a literal
     */
    public void export(Literal l) throws IOException;    
    
    /**
     * Indicates the start of an export process, allowing the exporter to 
     * write any initial data to the output (e.g. root element of an XML 
     * document)
     */
    public void start() throws IOException;
    
    /**
     * Indicates the end of an export process, allowing the exporter 
     * to write any final data to the output.
     */
    public void end() throws IOException;
}
