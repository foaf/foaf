package com.ldodds.foaf.thinlet.save;

import java.io.*;
import java.util.*;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.*;
/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class RDFExporter implements Exporter
{
    private Writer _out;
	private List _namespaces;
	private int _depth;
		    
    public RDFExporter()
    {
        _out = new BufferedWriter( new OutputStreamWriter(System.out) );
    	_namespaces = new ArrayList();    
    	_depth = 0;	
    }
    
    public void export(Person p) throws IOException
    {
        _depth++; 
    	String indent = getIndent();
        _out.write(indent + "<foaf:Person>\n");
        Map properties = p.getProperties();
        Iterator i = properties.values().iterator();
        _depth++;
        while (i.hasNext())
        {
            Object value = i.next();
            if (value instanceof Exportable)
            {
                Exportable e = (Exportable)value;
                e.export(this);                
                continue;
            }
            if (value instanceof List)
            {
                List values = (List)value;
                for (Iterator iterator = values.iterator(); iterator.hasNext(); )
                {
                    Exportable e = (Exportable)iterator.next();
                    e.export(this);                
                }
                continue;
            }
            //just write out objects if they can't write themselves
            _out.write(value.toString());
        }
        _depth--;
        _out.write(indent + "</foaf:Person>\n");
        _depth--;
    }
    
    public void export(Document d) throws IOException
    {
        _out.write("Document!" + d.toString() );
    }
        
    /**
     * @see com.ldodds.foaf.thinlet.Exporter#export(Literal)
     */
    public void export(Literal l) throws IOException
    {    	
        Object value = l.getValue();        
        if (value instanceof Exportable)
        {
            _depth++;
            _out.write(getIndent() + "<" + l.getPrefix() + ":" + l.getLocalName() + ">\n");                
            ( (Exportable)value ).export(this);
            _out.write(getIndent() + "</" + l.getPrefix() + ":" + l.getLocalName() + ">\n");            
            _depth--;              
        }
        else
        {
            _out.write(getIndent() + "<" + l.getPrefix() + ":" + l.getLocalName() + ">");                      
            _out.write(value.toString());            
            _out.write("</" + l.getPrefix() + ":" + l.getLocalName() + ">\n");
        }        
      
    }

    /**
     * @see com.ldodds.foaf.thinlet.Exporter#export(Resource)
     */
    public void export(Resource r) throws IOException
    {
    	String indent = getIndent();
        _out.write(indent + "<" + r.getPrefix() + ":" + r.getLocalName());
        _out.write(" rdf:about=\"" + r.getURI() + "\"");
        _out.write("/>\n");
    }
            
	/**
	 * @see com.ldodds.foaf.thinlet.Exporter#setOut(OutputStream)
	 */
	public void setOut(OutputStream out)
	{
        _out = new BufferedWriter( new OutputStreamWriter( out ) );
	}

	/**
	 * @see com.ldodds.foaf.thinlet.Exporter#end()
	 */
	public void end() throws IOException
	{		
		_out.write("</rdf:RDF>");
		_out.flush();
	}

	/**
	 * @see com.ldodds.foaf.thinlet.Exporter#start()
	 */
	public void start() throws IOException
	{
		_out.write("<rdf:RDF ");
		_depth++;
		String indent = getIndent();
		_out.write("\n");
		_out.write(indent + "xmlns:rdf=\"" + Constants.RDF.NS_URI + "\"\n");
		_out.write(indent + "xmlns:rdfs=\"" + Constants.RDFSchema.NS_URI + "\"\n");
        _out.write(indent + "xmlns:foaf=\"" + Constants.FOAF.NS_URI + "\">\n");
        
        _namespaces.add(Constants.RDFSchema.NS_URI);
        _namespaces.add(Constants.RDF.NS_URI);
        _namespaces.add(Constants.FOAF.NS_URI);
	}

	private String getIndent()
	{
		StringBuffer b = new StringBuffer();
		for (int i=0; i<_depth; i++)
		{
			b.append(" ");	
		}
		return b.toString();
	}
	
}
