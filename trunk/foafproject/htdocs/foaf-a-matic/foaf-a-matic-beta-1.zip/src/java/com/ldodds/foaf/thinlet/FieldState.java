package com.ldodds.foaf.thinlet;

import java.util.*;
import thinlet.Thinlet;
import java.lang.reflect.Method;
import java.awt.Image;

import com.ldodds.foaf.thinlet.ComponentManager;

/**
 * <p>
 * Describes the state of a field, used to cache a fields original status 
 * before altering it to (for example) display error cues. This wouldn't 
 * be required if the Thinlet framework allowed arbitrary annotation of 
 * components.
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class FieldState
{
    private Object _field;
    private Map _properties;
    private ComponentManager _thinlet;
    
    /**
     * Constructs a <code>FieldState</code> object 
     * referring to a given field.
     */
    public FieldState(ComponentManager thinlet, Object field)
    {
        _thinlet = thinlet;
        _field = field;
        _properties = new HashMap();
    }
    
    /**
     * Adds a property to this FieldState. Can be used to 
     * store original values of a fields properties so they can 
     * be later reset.
     */
    public void add(String property, Object value)
    {
        _properties.put(property, value);
    }
    
    public void add(String property, boolean b)
    {
        _properties.put(property, new Boolean(b));
    }
    
    public void add(String property, int i)
    {
        _properties.put(property, new Integer(i));
    }
    
    public void addChoice(String property, String choice)
    {
        _properties.put(property, new Choice(choice) );
    }
    
    /**
     * Resets this fields properties to the values of the properties 
     * contained in this <code>FieldState</code> instance.
     */
    public void reset()
    {
        Set keys = _properties.keySet();
        for (Iterator i=keys.iterator(); i.hasNext();)
        {
            String key = (String)i.next();
            Object value = _properties.get(key);
            if (value instanceof String)
            {
                _thinlet.setString(_field, key, (String)value);
            }
            else if (value instanceof Integer)
            {
                _thinlet.setInteger(_field, key, ((Integer)value).intValue());
            }
            else if (value instanceof Boolean)
            {
                _thinlet.setBoolean(_field, key, ((Boolean)value).booleanValue());
            }
            else if (value instanceof Choice)
            {
                _thinlet.setChoice(_field, key, ((Choice)value).getValue());
            }
            else if (value instanceof Image)
            {
                _thinlet.setIcon(_field, key, (Image)value);
            }
            else if (value instanceof Method)
            {
                //_thinlet.setMethod(_field, key, (Method)value);
            }                        
        }
    }


    /**
     * @see java.lang.Object#equals(Object)
     */
    public boolean equals(Object object)
    {
         if ( object == null ) {
            return false;
        }
        if ( object == this ) {
            return true;
        }
        if ( ! (object.getClass() == this.getClass()) ) {
            return false;
        }
        FieldState other = (FieldState) object;
        if ( ! other._field.equals( this._field ) ) {
            return false;
        }
        return true;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    public int hashCode()
    {
        return _field.hashCode();
    }

    /**
     * Convenience class to help type different kinds of field properties
     */
    private class Choice
    {
        private String _value;
        
        public Choice(String value)
        {
            _value = value;  
        }

        public String getValue()
        {
            return _value;
        }
    }
        

}
