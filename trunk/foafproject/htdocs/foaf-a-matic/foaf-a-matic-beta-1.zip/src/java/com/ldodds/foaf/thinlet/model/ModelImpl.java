package com.ldodds.foaf.thinlet.model;

import java.util.*;

/**
 * Simple model implementation.
 *  
 * @author ldodds
 * @see Model
 */
public class ModelImpl implements Model
{

	private Person _person; 

	public ModelImpl()
	{
		_person = new Person();
	}
	
	/**
	 * @see com.ldodds.foaf.thinlet.model.Model#getCurrentPerson()
	 */
	public Person getCurrentPerson()
	{
		return _person;
	}

	/**
	 * @see com.ldodds.foaf.thinlet.model.Model#getFriends()
	 */
	public List getFriends()
	{
		return _person.getAsList(Person.FRIENDS);
	}

	/**
	 * @see com.ldodds.foaf.thinlet.model.Model#addFriend(Person)
	 */
	public void addFriend(Person friend)
	{
		if (_person == null)
		{
			_person = new Person();
		}
        FOAFPropertyBuilder builder = new FOAFPropertyBuilder();
		_person.addAsList(Person.FRIENDS, builder.makeProperty(Person.FRIENDS, friend));
        
	}

	/**
	 * @see com.ldodds.foaf.thinlet.model.Model#setCurrentPerson()
	 */
	public void setCurrentPerson(Person p)
	{
		_person = p;	
	}

	/**
	 * @see com.ldodds.foaf.thinlet.model.Validatable#getErrors()
	 */
	public List getErrors()
	{
		return _person.getErrors();
	}

	/**
	 * @see com.ldodds.foaf.thinlet.model.Validatable#validate()
	 */
	public boolean validate()
	{
		return _person.validate();
	}

}
