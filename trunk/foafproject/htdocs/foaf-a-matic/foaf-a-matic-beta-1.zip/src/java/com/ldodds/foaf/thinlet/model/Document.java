package com.ldodds.foaf.thinlet.model;
import java.io.IOException;

import com.ldodds.foaf.thinlet.save.*;

/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class Document extends FOAFObject
{
	/**
	 * @see com.ldodds.foaf.thinlet.Exportable#export(Exporter)
	 */
	public void export(Exporter exporter) throws IOException
	{
        exporter.export(this);
	}
}
