package com.ldodds.foaf.thinlet.model;

import java.util.List;

/**
 * <p>
 * An object that can validate itself.
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public interface Validatable
{
    /**
     * Asks the object to validate itself. No indication of 
     * validation errors are returned. These should be inspected 
     * with @see #getErrors.
     * 
     * @return <code>true</code> is the object is valid.
     */
    public boolean validate();
    
    /**
     * Asks the object for validation errors.
     * 
     * @return null if there are no errors, otherwise a list of ValidationErrors
     */
    public List getErrors();
}
