package com.ldodds.foaf.thinlet.model;

import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import com.ldodds.foaf.thinlet.save.*;
import com.ldodds.foaf.thinlet.*;
/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public abstract class FOAFObject extends AnnotableObject implements Validatable, Exportable
{
    private List _errors;

    /**
     * Convenience method for sub-classes allowing validation messages 
     * to be added to an internal list.
     */
    protected void addValidationError(ValidationError error)
    {
        if (_errors == null)
        {
            _errors = new ArrayList();
        }
        _errors.add( error );
    }
       
	/**
	 * @see com.ldodds.foaf.thinlet.Validatable#getErrors()
	 */
	public List getErrors()
	{
		return _errors;
	}

	/**
	 * @see com.ldodds.foaf.thinlet.Validatable#validate()
	 */
	public final boolean validate()
	{
        _errors = new ArrayList();
		return doValidation();
	}

    /**
     * Should be overridden by sub-classes to provide validation 
     * behaviour
     */
    protected boolean doValidation()
    {
        return true;        
    }
  
    public abstract void export(Exporter exporter) throws IOException;  
}
