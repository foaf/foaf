package com.ldodds.foaf.thinlet.model;

import java.util.List;

/**
 * A FOAF data model.
 * 
 * <p>
 * A Model is constructed in two main circumstances: when reading data from the 
 * GUI prior to exporting, and when importing data from other data sources.
 * </p>
 * <p>
 * This interface isn't especially RDF-centric but can be seen as an abstraction over 
 * an RDF data model/graph that provides useful functionality for FOAF apps. It should 
 * be relatively straight-forward to create instances of this model that manipulate 
 * true RDF graphs underneath.
 * </p>
 * <p>
 * <b>This is very much likely to change: its the bit of the app that I'm least comfortable 
 * with at the moment!</b>
 * </p>
 * @author ldodds
 */
public interface Model extends Validatable
{

	/**
	 * Retrieves the current person, i.e the representation of the user entering 
	 * data into the application.
	 * 
	 * @return the current person
	 */
	public Person getCurrentPerson();
	
	/**
	 * Retrieves the friends of the current person. 
	 * 
	 * @return a List of Person objects.
	 */	
	public List getFriends();	
	
	/**
	 * Sets the current person
	 * 
	 * @return a Person object. Cannot be <code>null</code>
	 */
	public void setCurrentPerson(Person p);
	
	/**
	 * Adds a friend of the current person.
	 * 
	 * If the current person is null then a new empty person should be 
	 * created.
	 */	
	public void addFriend(Person friend);	
	
}
