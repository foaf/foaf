package com.ldodds.foaf.thinlet;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.*;

/**
 * 
 * @author ldodds
 */
public class ModelBuilder
{
	private PersonBuilder _personBuilder;
	private FriendBuilder _friendBuilder;
    
	public ModelBuilder()
	{
		_personBuilder = new PersonBuilder();
        _friendBuilder = new FriendBuilder();
	}
	
	public void build()
	{
        Services.getModel().setCurrentPerson(new Person());
		_personBuilder.build();	
        _friendBuilder.build();
	}
	
}
