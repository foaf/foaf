package com.ldodds.foaf.thinlet;

import thinlet.Thinlet;
import java.util.*;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.*;
/**
 * <p>
 * Responsible for building people data, based on user input
 * </p>
 * <p>
 * This class walks through the fields in the user interface to generate an internal 
 * representation of the personal data entered by the user. This data can then be used to 
 * validate the input.
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class PersonBuilder
{
    private PropertyBuilder _foafBuilder;
    private ComponentManager _thinlet;
    private Model _model;
    
    public PersonBuilder()
    {
        _thinlet = Services.getComponentManager();
        _foafBuilder = new FOAFPropertyBuilder();
        _model = Services.getModel();
    }
    
    /**
     * Builds the internal data model based on the information that 
     * the user has entered into the user interface. Does not validate 
     * any of the data, for this call <code>validate</code>
     */
    public void build()
    {
        processTab( _thinlet.find("personal")); 
        processTab( _thinlet.find("work"));
    }
    
    private void processTab(Object tab)
    {
        Object[] contents = _thinlet.getItems(tab);
        for (int i=0; i<contents.length; i++)
        {
            String name = _thinlet.getString(contents[i], "name");
            if (name != null && !name.endsWith("_label"))
            {
				addProperty(name, _thinlet.getString(contents[i], "text"));
            }
        }        
    }
        
    /**
     * <p>
     * Validates the data currently in the builder 
     * (mainly the current person) to 
     * ensure required fields have been entered. If not then the FOAF export is 
     * cancelled, and the user is shown a dialog directing them to fix the errors.
     * </p>
     * <p>
     * The user interface is also updated to include some visual cues.
     * </p>
     * @deprecated
     */
    public boolean validate()
    {
        Person p = _model.getCurrentPerson();
        if (p.validate())                       
        {
            return true;
        }
        Services.getDialogs().showDialog("error-dialog");
        return false;                    
    }    


    /**
     * @deprecated
     */    
    public void updateCurrentPerson(String firstname, String surname, String email)
    {
        addProperty(Person.FIRSTNAME, firstname);
        addProperty(Person.LASTNAME, surname);
        addProperty(Person.EMAIL, email);
    }
    
    /**
     * Adds a property to the person currently being built
     * 
     * @param property the property name
     * @param value the value of the property
     */
    public void addProperty(String property, String value)
    {
        //strip prefix
        String prop = property.substring(property.indexOf(":") + 1);        
                
        if (value != null && !value.equals(""))
        {
            if (_foafBuilder.canBuildProperty(property))
            {
                _model.getCurrentPerson().add(prop, _foafBuilder.makeProperty(prop, value));
            }
        }
    }
    
}
