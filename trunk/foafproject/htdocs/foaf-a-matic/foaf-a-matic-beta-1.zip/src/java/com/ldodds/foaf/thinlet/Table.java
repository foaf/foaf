package com.ldodds.foaf.thinlet;

import java.util.*;

/**
 * Dynamically add rows to tables
 * @author ldodds
 */
public class Table
{

    private String _name;
    
    public Table(String name)
    {
        _name = name;
    }
    
	/**
	 * Dynamically adds a row of data to a table.
	 * 
	 * @param name the name of the table component
	 * @param data an array containing one entry for each cell in the row. Cells
	 * 					   are added in array order.
	 */
	public void add(Object[] data)
	{
		Object table = getTable();
		Object row = makeRow();
		for (int i=0; i<data.length; i++)
		{
			Object cell = makeCell();
			Services.getComponentManager().setString(cell, "text", data[i].toString());
			Services.getComponentManager().add(row, cell);
		}
		Services.getComponentManager().add(table, row);			
	}
	
    public void updateSelected(Object[] data)
    {
        Object table = getTable();
        Object row = getFirstSelectedRow();
        
        if (row == null)
        {
            add(data);
            return;
        }
        
        Object[] cells = Services.getComponentManager().getItems(row);
        
        for (int i=0; i<cells.length;i++)
        {
            Object cell = cells[i];
            Services.getComponentManager().setString(cell, "text", data[i].toString());            
        }
    }
    
	/**
	 * Deletes the currently selected rows from a table
	 * 
	 * @param name the name of the table component
	 */
	public void deleteSelectedRows()
	{
		for (int i=getRowCount()-1; i>=0; i--)
		{
			if (rowSelected(i))
			{
				deleteRow(i);
			}
		}		
	}
    
    public Object getFirstSelectedRow()
    {
        for (int i=0; i<getRowCount(); i++)
        {
            if (rowSelected(i))
            {
                return getRow(i);
            }
        }
        return null;            
    }

    public List getSelectedCellData()
    {
        return getCellData(getFirstSelectedRow());
    }
    
    public List getCellData(Object row)
    {
        Object[] cells = getCells(row);
        List values = new ArrayList(cells.length);        
        for (int i=0; i<cells.length; i++)
        {
            values.add( getText(row, i) );
        }
        
        return values;    
    }

    public Object getCell(Object row, int cell)
    {
        return Services.getComponentManager().getItem(row, cell);
    }
    
    public Object[] getCells(int row)
    {
        return getCells(getRow(row));
    }
    
    public Object[] getCells(Object row)
    {
        return Services.getComponentManager().getItems(row);
    }
            
    public Object makeRow()
    {
        return Services.getComponentManager().create("row");
    }
    
    public Object makeCell()
    {
        return Services.getComponentManager().create("cell");        
    }
    
    public Object getTable()
    {
        return Services.getComponentManager().find(_name);  
    }

    public void deleteRow(int i)
    {
        Services.getComponentManager().remove(getRow(i));        
    }
    
    public boolean rowSelected(int i)
    {
        return Services.getComponentManager().getBoolean(getRow(i), "selected");
    }
    
    public Object getRow(int i)
    {
        return Services.getComponentManager().getItem(getTable(), i);
    }

    public List getRows()
    {
        return Arrays.asList(Services.getComponentManager().getItems(getTable()));
    }   
    public int getRowCount()
    {
        return Services.getComponentManager().getCount(getTable());   
    }    
    
    public String getText(Object row, int cell)
    {
        return Services.getComponentManager().getString(getCell(row, cell), "text");
    }
    
}
