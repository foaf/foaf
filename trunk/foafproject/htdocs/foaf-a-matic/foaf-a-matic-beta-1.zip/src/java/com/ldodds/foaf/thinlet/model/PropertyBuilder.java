package com.ldodds.foaf.thinlet.model;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.util.*;
/**
 *<p>
 * Turns fields from the GUI into Property (i.e. Literal and Resource objects)
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public abstract class PropertyBuilder
{
    private String _nsuri;
    private String _prefix;
    
    public PropertyBuilder(String nsuri, String prefix)
    {
        _nsuri = nsuri;
        _prefix = prefix;
    }
    
    public boolean canBuildProperty(String property)
    {
        return property.startsWith(_prefix);
    }
    
    public abstract Object makeProperty(String property, Object value);
    
    protected Literal makeLiteral(String property, Object value)
    {
        return new Literal(_prefix, property, _nsuri, value);
    }

    protected Literal makeLiteral(String property, Object value, Encryptor encryptor)
    {
        return new Literal(_prefix, property, _nsuri, value, encryptor);
    }
    
    protected Resource makeResource(String property, Object value)
    {
        return new Resource(_prefix, property, _nsuri, (String)value);
    }
}
