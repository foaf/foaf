package com.ldodds.foaf.thinlet.model;

import java.io.IOException;

import com.ldodds.foaf.thinlet.save.*;
/**
 * <p>
 * An RDF Resource
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class Resource extends Property
{
    private String _uri;
    
    public Resource(String prefix, String localname, String namespaceuri, String uri)
    {
        super(prefix, namespaceuri,localname);
        _localname = localname;
        _uri = uri;
    }
                
	/**
	 * @see com.ldodds.foaf.thinlet.Exportable#export(Exporter)
	 */
	public void export(Exporter exporter) throws IOException
	{
        exporter.export(this);
	}


    public String getURI()
    {
        return _uri;
    }
    
    public String toString()
    {
        return "[Resource]" + _prefix + ":" + _localname + "," + _uri;
    }
}
