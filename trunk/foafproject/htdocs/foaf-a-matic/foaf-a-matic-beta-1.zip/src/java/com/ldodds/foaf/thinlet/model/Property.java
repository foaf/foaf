package com.ldodds.foaf.thinlet.model;

import java.io.IOException;
import java.security.*;

import com.ldodds.foaf.thinlet.save.*;
/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public abstract class Property implements Exportable
{
    protected String _prefix;
    protected String _localname;
    protected String _namespaceuri;
        
    public Property(String prefix, String namespaceuri, String localname)
    {
        _prefix = prefix;
        _localname = localname;
        _namespaceuri = namespaceuri;
    }
    
    public String getPrefix()
    {
        return _prefix;
    }
    
    public String getLocalName()
    {
        return _localname;
    }
      
	public String getNamespaceURI()
	{
		return _namespaceuri;
	}
	            
    /**
     * @see com.ldodds.foaf.thinlet.Exportable#export(Exporter)
     */
    public abstract void export(Exporter exporter) throws IOException;
}
