package com.ldodds.foaf.thinlet.model;

/**
 * A utility interface for holding constants
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public interface Constants
{
    public interface FOAF
    {
        public static final String NS_URI = "http://xmlns.com/foaf/0.1/";
    }
    
    public interface RDF
    {
    	public static final String NS_URI = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    }
    
    public interface RDFSchema
    {
    	public static final String NS_URI = "http://www.w3.org/2000/01/rdf-schema#";
    }
}
