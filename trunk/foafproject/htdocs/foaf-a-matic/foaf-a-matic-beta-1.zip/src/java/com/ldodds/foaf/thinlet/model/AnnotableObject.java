package com.ldodds.foaf.thinlet.model;

import java.util.*;

/**
 * Base class for Annotable objects. Implements the Annotable 
 * interface
 * 
 * @author ccslrd
 * @see com.ldodds.foaf.thinlet.Annotable
 */
public class AnnotableObject implements Annotable
{
    protected Map _properties;
    
    public AnnotableObject()
    {
        _properties = new HashMap();
    }
    
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#add(String, Object)
	 */
	public void add(String property, Object value)
	{
        _properties.put(property, value);
	}
    
    /**
     * @see com.ldodds.foaf.thinlet.Annotable#addAsList(String, Object)
     */
    public void addAsList(String property, Object value)
    {    
        Object currentValue = _properties.get(property);
        List values = null;
        if (currentValue == null)
        {
            values = new ArrayList();
            values.add(value);  
        }
        if (currentValue instanceof List)
        {
            values = (List)currentValue;
            values.add(value);
        }
        if (currentValue instanceof String)
        {
            values = new ArrayList();
            values.add(currentValue);
            values.add(value);
        }
        //so hashcode is recalculated...?
        _properties.put(property, values);        
    }
    
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#add(Annotable)
	 */
	public void add(Annotable other)
	{
        _properties.putAll(other.getProperties());
	}
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#get(String)
	 */
	public Object get(String property)
	{
		return _properties.get(property);
	}
	
	
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#has(String)
	 */
	public boolean has(String property)
	{
		return _properties.containsKey(property);
	}
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#getProperties()
	 */
	public Map getProperties()
	{
		return Collections.unmodifiableMap(_properties);
	}
	
	/**
	 * @see com.ldodds.foaf.thinlet.Annotable#getAsList(String)
	 */
	public List getAsList(String property)
	{
		Object obj = get(property);
		if (obj instanceof List)
		{
			return (List)obj;
		}
		List newList = new ArrayList();
		if (obj != null)
		{
			newList.add(obj);
		}
		return Collections.unmodifiableList(newList);		
	}

}
