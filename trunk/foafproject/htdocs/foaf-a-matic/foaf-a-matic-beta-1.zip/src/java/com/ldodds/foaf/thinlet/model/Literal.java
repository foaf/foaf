package com.ldodds.foaf.thinlet.model;
import java.io.IOException;

import com.ldodds.foaf.thinlet.*;
import com.ldodds.foaf.thinlet.save.*;
import com.ldodds.foaf.thinlet.util.Encryptor;
/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class Literal extends Property
{
    private Object _value;
    
    private Encryptor _encryptor;
        
    public Literal(String prefix, String localname, String namespaceuri, Object value)
    {
        this(prefix, localname, namespaceuri, value, null);
    }

    public Literal(String prefix, String localname, String namespaceuri, Object value, Encryptor encryptor)
    {
        super(prefix, namespaceuri, localname);
        _value = value;
        _encryptor = encryptor;
    }
    
	/**
	 * @see com.ldodds.foaf.thinlet.Exportable#export(Exporter)
	 */
	public void export(Exporter exporter) throws IOException
	{
        exporter.export(this);
	}

    public boolean isEncypted()
    {
        return _encryptor != null;
    }
    
    public Object getValue()
    {
        return (_encryptor != null ? _encryptor.encrypt(_value.toString()) : _value);
    }
    
}
