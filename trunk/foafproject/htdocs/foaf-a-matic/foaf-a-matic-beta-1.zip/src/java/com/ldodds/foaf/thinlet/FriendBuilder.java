package com.ldodds.foaf.thinlet;

import java.util.*;

import com.ldodds.foaf.thinlet.model.*;

/**
 * Populates the Friend table in the user interface, and uses that data to populate
 * the model.
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class FriendBuilder
{
    private Table _table;
    private PropertyBuilder _foafBuilder;
    
    public FriendBuilder()
    {
        _table = new Table("friends");
        _foafBuilder = new FOAFPropertyBuilder();
    }
    
    /**
     * Add/update a friend in the table. Performs validation on the entered fields
     */
    public void addFriendToTable(boolean update)
    {
        Object friendsTab = Services.getComponentManager().find("friend_entry");

        String[] columns = new String[5];
        Arrays.fill(columns, ""); 
                  
        boolean successful = true;                
        Object firstName = Services.getComponentManager().find("foaf:friend_firstName");
        successful = addToArray(columns, firstName, 0, true) && successful;

        Object surname = Services.getComponentManager().find("foaf:friend_surname");
        successful = addToArray(columns, surname, 1, true) && successful;
        
        Object email = Services.getComponentManager().find("foaf:friend_mbox");
        successful = addToArray(columns, email, 2, true) && successful;
        
        Object nick = Services.getComponentManager().find("foaf:friend_nick");
        addToArray(columns, nick, 3, false);
        //successful = successful && addToArray(columns, nick, 3, false);

        Object foaf = Services.getComponentManager().find("rdfs:friend_seeAlso");
        addToArray(columns, foaf, 4, false);
        //successful = successful && addToArray(columns, foaf, 4, false);

        if (successful)
        {
            if (update)
            {
                _table.updateSelected(columns);
            }
            else
            {
                _table.add(columns);
            }
        }
    }      

    /**
     * Populate the data entry fields from the row currently selected in the table.
     */
    public void showSelected()
    {
        Object friendsTab = Services.getComponentManager().find("friend_entry");
        List data = _table.getSelectedCellData();

        Object firstName = Services.getComponentManager().find("foaf:friend_firstName");
        Services.getComponentManager().setString(firstName, "text", (String)data.get(0));

        Object surname = Services.getComponentManager().find("foaf:friend_surname");
        Services.getComponentManager().setString(surname, "text", (String)data.get(1));
        
        Object email = Services.getComponentManager().find("foaf:friend_mbox");
        Services.getComponentManager().setString(email, "text", (String)data.get(2));
        
        Object nick = Services.getComponentManager().find("foaf:friend_nick");
        Services.getComponentManager().setString(nick, "text", (String)data.get(3));

        Object foaf = Services.getComponentManager().find("rdfs:friend_seeAlso");
        Services.getComponentManager().setString(foaf, "text", (String)data.get(4));        
    }

    /**
     * Add field data to the provided array. As a side-effect will trigger showing of data entry
     * hints if required fields aren't provided.
     */            
    public boolean addToArray(String[] fields, Object field, int index, boolean required)
    {
        String value = getText(field);
        if (isNullOrEmpty(value) && required)
        {
            showCue(field);            
            return false;
        }
        else if (isNullOrEmpty(value))
        {
            return false;
        }
        fields[index] = value;
        return true;        
    }
    
    /**
     * Show data entry hints
     */
    public void showCue(Object field)
    {
        String name = Services.getComponentManager().getString(field, "name");
        Object fieldLabel = Services.getComponentManager().find(name + "_label");
        
        FieldState state = new FieldState(Services.getComponentManager(), fieldLabel);
        state.add("icon", Services.getComponentManager().getIcon(fieldLabel, "icon"));
        state.add("tooltip", Services.getComponentManager().getString(fieldLabel, "tooltip"));                
        
        Services.getFieldStateManager().addFieldState(fieldLabel, state);
        
        Services.getComponentManager().setIcon(fieldLabel, "icon", Services.getComponentManager().getIcon("/icons/redface.gif"));
        Services.getComponentManager().setString(fieldLabel, "tooltip", "You must provide a " + name);        
    }

    /**
     * Adds friends data, stored in the table, to the internal model
     */
    public void build()
    {
        Model model = Services.getModel();
        for (Iterator iterator = _table.getRows().iterator(); iterator.hasNext();)
        {
            Object row = iterator.next();
            List data = _table.getCellData(row);
            Person friend = new Person();
            FOAFPropertyBuilder builder = new FOAFPropertyBuilder();
            addPropertyToFriend(friend, Person.FIRSTNAME, (String)data.get(0) );
            addPropertyToFriend(friend, Person.LASTNAME, (String)data.get(1) );
            addPropertyToFriend(friend, Person.EMAIL, (String)data.get(2) );
            addPropertyToFriend(friend, Person.NICKNAME, (String)data.get(3) );                                    
            
            if (!isNullOrEmpty( (String)data.get(4) ) )
            {
                friend.add("seeAlso", new Resource("rdfs", "seeAlso", Constants.RDFSchema.NS_URI, (String)data.get(4)) );
            }
            model.addFriend(friend);
        }
    }
            
    private void addPropertyToFriend(Person p, String property, String value)
    {
        if (!isNullOrEmpty(value))
        {
            p.add(property, _foafBuilder.makeProperty(property, value));            
        }
    }
                
    public boolean isNullOrEmpty(String value)
    {
        return (value == null || "".equals(value) );
    }
    
    public String getText(Object field)
    {
        return Services.getComponentManager().getString(field, "text");
    }
      
    public String getText(Object context, String field)
    {
        return 
            getText( Services.getComponentManager().find(context, field) );
    }
    
    public String getProperName(String name)
    {
        return "foaf:" + name.substring(name.lastIndexOf("_") + 1);
    }
    
    /**
     * Remove existing friend(s) from the table
     */
    public void removeFriendFromTable()
    {
        _table.deleteSelectedRows();        
    }
                    
    /**
     * Populate the current model with data stored in the friend table
     */
    public void populateModel()
    {
    }
    
}
