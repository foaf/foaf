package com.ldodds.foaf.thinlet.model;

import com.ldodds.foaf.thinlet.*;
import com.ldodds.foaf.thinlet.save.*;

import java.io.IOException;

/**
 * Models a FOAF Person.
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class Person extends FOAFObject
{
	public static final String FIRSTNAME = "firstName";
	public static final String LASTNAME = "surname";
	public static final String TITLE = "title";
	public static final String EMAIL = "mbox";
    public static final String EMAIL_ENCRYPTED = "mbox_sha1sum";    
	public static final String HOMEPAGE = "homepage";
	public static final String DEPICTION = "depiction";
	public static final String NICKNAME = "nick";
	public static final String PHONE = "phone";
	public static final String FRIENDS = "knows";
    public static final String SCHOOL = "schoolHomepage";
    public static final String WORK = "workplaceHomepage";
    public static final String ABOUT_WORK = "workInfoHomepage";
	public static final String PUBLICATIONS = "publications";
    
	/**
	 * @see com.ldodds.foaf.thinlet.FOAFObject#doValidation()
	 */
	protected boolean doValidation()
	{
		boolean valid = true;
		if ( !has(FIRSTNAME) )
		{
            addValidationError( ValidationError.createMissingFieldError(FIRSTNAME));
            valid = false;
		}
        if ( !has(LASTNAME) )
        {
            addValidationError( ValidationError.createMissingFieldError(LASTNAME));
            valid = false;
        }
        if ( !has(EMAIL))
        {
            addValidationError( ValidationError.createMissingFieldError(EMAIL));
            valid = false;            
        }        
        return valid;
	}
    
    public void export(Exporter exporter) throws IOException
    {
        exporter.export(this);
    }
}
