package com.ldodds.foaf.thinlet;

import java.awt.Frame;

import thinlet.Thinlet;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.save.*;

/**
 * A registry of services used by this application.
 * 
 * @author ccslrd
 */
public class Services
{
    private static Preferences _preferences;
    private static Dialogs _dialogs;
    private static Frame _frame;
    private static Model _model;
    private static ModelBuilder _modelBuilder;
    private static FieldStateManager _fieldManager;
    private static ComponentManager _componentManager;
    
    static void init(ComponentManager manager, Frame frame)
    {
        if (manager == null)
        {
            throw new IllegalArgumentException("Cannot have null ComponentManager");
        }
        if (frame == null)
        {
            throw new IllegalArgumentException("Cannot have null Frame");            
        }
        
        _componentManager = manager;
        _frame = frame;
        _preferences = new Preferences();
        _dialogs = new Dialogs();
        _model = new ModelImpl();
        _modelBuilder = new ModelBuilder();
        _fieldManager = new FieldStateManager();
    }
                    
    public static final Preferences getPreferences()
    {
        return _preferences;
    }
            
    public static final Dialogs getDialogs()
    {
        return _dialogs;
    }
    
    public static final Frame getFrame()
    {
        return _frame;
    }
    
    public static final Model getModel()
    {
        return _model;
    }
    
    public static final ModelBuilder getModelBuilder()
    {
        return _modelBuilder;
    }
    
    public static final FieldStateManager getFieldStateManager()
    {
        return _fieldManager;
    }
    
    public static final ComponentManager getComponentManager()
    {
        return _componentManager;
    }
    
}
