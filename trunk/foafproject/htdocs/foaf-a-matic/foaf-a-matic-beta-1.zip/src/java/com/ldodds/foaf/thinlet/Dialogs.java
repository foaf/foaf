package com.ldodds.foaf.thinlet;

import java.util.*;

import com.ldodds.foaf.thinlet.*;

/**
 * 
 * @author ldodds
 */
public class Dialogs
{
	private Map _dialogs;
	
	public Dialogs()
	{
		_dialogs = new HashMap();
	}
	
	public void closeDialog(String name)
	{
    	Object dialog = getDialog(name);
    	if (dialog != null)
    	{
        	Services.getComponentManager().remove(dialog);
    	}
		
	}
		
	public Object getDialog(String name)
	{
		try
		{
			Object dialog = _dialogs.get(name);
			if (dialog == null)
			{
				dialog = Services.getComponentManager().parse("/ui/" +name + ".xml");
				_dialogs.put(name, dialog);
			}
			return dialog;
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}	

	public void showDialog(String name)
	{
    	Object dialog = getDialog(name);
    	if (dialog != null)
    	{
    		Services.getComponentManager().add(dialog);
    	}    	
		
	}
}
