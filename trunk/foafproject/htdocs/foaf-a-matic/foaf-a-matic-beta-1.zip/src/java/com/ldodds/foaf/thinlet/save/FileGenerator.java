package com.ldodds.foaf.thinlet.save;

import java.io.*;
import java.awt.*;

import com.ldodds.foaf.thinlet.*;
import com.ldodds.foaf.thinlet.model.*;

/**
 * 
 * @author ldodds
 */
public class FileGenerator extends Generator
{
	
	/**
	 * @see com.ldodds.foaf.thinlet.save.Generator#doGeneration()
	 */
	protected void doGeneration()
	{
		FileOutputStream _out = null;
		try
		{

			FileDialog fileDialog = new FileDialog(Services.getFrame(), "Save FOAF data...", FileDialog.SAVE);
			fileDialog.show();
				
			if (fileDialog.getFile() == null)
			{
				return;
			}
				
			_out = new FileOutputStream(
					new File(fileDialog.getDirectory(), 
								  fileDialog.getFile()));			
			Exporter exporter = Services.getPreferences().getExporter();
			exporter.setOut(_out);
			doExport(exporter);								  
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (_out != null)
			{
				try { _out.close(); } catch (Exception e) {}
			}
		}		
	}
}
