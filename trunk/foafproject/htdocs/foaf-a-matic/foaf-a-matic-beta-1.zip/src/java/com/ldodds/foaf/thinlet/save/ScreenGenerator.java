package com.ldodds.foaf.thinlet.save;

import com.ldodds.foaf.thinlet.*;

/**
 * 
 * @author ldodds
 */
public class ScreenGenerator extends Generator
{
	
	/**
	 * @see com.ldodds.foaf.thinlet.save.Generator#doGeneration()
	 */
	protected void doGeneration()
	{
		Object dialog = Services.getDialogs().getDialog("foaf-dump-dialog");
		_thinlet.add(dialog);
		Object data = _thinlet.find(dialog, "data2");     
		 _thinlet.setString(data, "text", getFOAFString());            
	}

}
