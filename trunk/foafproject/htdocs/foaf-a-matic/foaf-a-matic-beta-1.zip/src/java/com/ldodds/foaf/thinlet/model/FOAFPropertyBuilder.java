package com.ldodds.foaf.thinlet.model;

import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.util.*;
import com.ldodds.foaf.thinlet.*;
/**
 * 
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class FOAFPropertyBuilder extends PropertyBuilder
{
    
	public FOAFPropertyBuilder()
	{
		super(Constants.FOAF.NS_URI, "foaf");
	}

    public Object makeProperty(String prop, Object value)
    {
        if (prop.equals(Person.DEPICTION) ||
            prop.equals(Person.HOMEPAGE) ||
            prop.equals(Person.SCHOOL) ||
            prop.equals(Person.WORK) ||
            prop.equals(Person.ABOUT_WORK))
        {
            return makeResource(prop, value);
        }            
        else if (prop.equals(Person.EMAIL))
        {        	
            if (Services.getPreferences().hideEmailAddresses())
            {
                return makeLiteral(prop + "_sha1sum",  "mailto:" + value, new SHA1Encryptor());
            }
            else
            {
                return makeLiteral(prop, value);
            }            
        }
        else if (prop.equals(Person.PHONE))
        {
            return makeResource(prop, "tel:" + value);
        }
        else if (prop.equals(Person.FRIENDS))
        {      
            return makeLiteral(prop, value);    
        }
        else
        {
            return makeLiteral(prop, value);
        }
    }

}
