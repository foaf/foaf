package com.ldodds.foaf.thinlet.save;

import java.io.IOException;
import java.io.OutputStream;

import com.ldodds.foaf.thinlet.model.Document;
import com.ldodds.foaf.thinlet.model.Literal;
import com.ldodds.foaf.thinlet.model.Person;
import com.ldodds.foaf.thinlet.model.Resource;

/**
 * 
 * @author ldodds
 */
public class NotationThreeExporter implements Exporter
{

	private OutputStream _out = System.out;
	
	/**
	 * Constructor for NotationThreeExporter.
	 */
	public NotationThreeExporter()
	{
		super();
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#setOut(OutputStream)
	 */
	public void setOut(OutputStream out)
	{
		_out = out;		
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#export(Person)
	 */
	public void export(Person p) throws IOException
	{
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#export(Document)
	 */
	public void export(Document d) throws IOException
	{
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#export(Resource)
	 */
	public void export(Resource r) throws IOException
	{
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#export(Literal)
	 */
	public void export(Literal l) throws IOException
	{
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#start()
	 */
	public void start() throws IOException
	{
		_out.write("Not Yet Implemented!!".getBytes());
	}

	/**
	 * @see com.ldodds.foaf.thinlet.save.Exporter#end()
	 */
	public void end() throws IOException
	{
		_out.flush();
	}

}
