package com.ldodds.foaf.thinlet.save;

import java.awt.*;
import java.awt.datatransfer.*;

import com.ldodds.foaf.thinlet.*;

/**
 * 
 * @author ldodds
 */
public class ClipboardGenerator extends Generator
{
	
	/**
	 * @see com.ldodds.foaf.thinlet.save.Generator#doGeneration()
	 */
	protected void doGeneration()
	{
		try
		{
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			StringSelection selection = new StringSelection(getFOAFString());
			clipboard.setContents(selection, null);            
		} catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
}
