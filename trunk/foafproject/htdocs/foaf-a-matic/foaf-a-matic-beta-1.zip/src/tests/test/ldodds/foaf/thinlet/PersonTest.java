package test.ldodds.foaf.thinlet;

import junit.framework.TestCase;
import com.ldodds.foaf.thinlet.*;
import com.ldodds.foaf.thinlet.model.*;
import com.ldodds.foaf.thinlet.save.*;
import java.util.*;
import java.io.*;

/**
 * <p>
 * Tests for the Person class
 * </p>
 * <p>
 * This code is Public Domain
 * </p>
 * 
 * @author ccslrd
 */
public class PersonTest extends TestCase
{
	/**
	 * Constructor for PersonTest.
	 * @param arg0
	 */
	public PersonTest(String arg0)
	{
		super(arg0);
	}
    
    public void testValidation()
    {
        Person p = new Person();    
        assertTrue( !p.validate() );
        
        List errors = p.getErrors();
        assertTrue( errors.size() == 3 );
        
        p.add(Person.FIRSTNAME, "Leigh");
        p.add(Person.LASTNAME, "Dodds");
        p.add(Person.EMAIL, "foafthinlet@ldodds.com");
        assertTrue( p.validate() );        
    }
    
    public void testExport() throws Exception
    {
        RDFExporter exporter = new RDFExporter();
        FOAFThinlet thinlet = new FOAFThinlet();
        PersonBuilder p = new PersonBuilder();
        p.updateCurrentPerson("Leigh", "Dodds", "ldodds@ingenta.com");        
        exporter.start();
        Services.getModel().getCurrentPerson().export(exporter);
        exporter.end();
    }
    
	public static void main(String[] args)
	{
		junit.textui.TestRunner.run(PersonTest.class);
	}
}
